##############################################################################
#    Description: Sale Customization                                   #
#    Author: IntelliSoft Software                                            #
#    Date: May 2020 -  Till Now                                              #
##############################################################################

from odoo.exceptions import UserError, AccessError, Warning ,ValidationError
from odoo import api, exceptions, fields, models, _


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    delivery_state = fields.Selection([
        ('not_delivered', 'Not Delivered'),
        ('delivered', 'Delivered'),
    ], string='Delivery Status', copy=False, index=True, default='not_delivered')
    actual_delivery = fields.Date('Actual Delivery')
    delivered_to = fields.Char('Delivered To')
    deduct_down_payments = fields.Boolean('Deduct down payments', default=True)
    invoice_id = fields.Many2one('account.move', 'Open Invoice', store=True)

    def action_done(self):
        res = super(StockPicking, self).action_done()
        # if self.picking_type_id.code == 'outgoing':
        if self.sale_id:
            self.sale_id.delivery_from_stock_date = fields.Date.today()
            if self.sale_id.state in ['sale', 'done']:
                if self.sale_id.team_id.auto_invoice:
                    x = self.sale_id._create_invoices(final=self.deduct_down_payments)
                    self.write({'invoice_id': x})
                    self.invoice_id.post()
                    fm_group_id = self.env['res.groups'].sudo().search([('name', 'like', 'Sale Order Confirmation')],
                                                                       limit=1).id
                    self.env.cr.execute(
                        '''SELECT uid FROM res_groups_users_rel WHERE gid = %s order by uid''' % (fm_group_id))
                    for fm in list(filter(lambda x: (
                            self.env['res.users'].sudo().search([('id', '=', x)]).company_id == self.company_id),
                                          self.env.cr.fetchall())):
                        vals = {
                            'activity_type_id': self.env['mail.activity.type'].sudo().search(
                                [('name', 'like', 'Stock Picking')],
                                limit=1).id,
                            'res_id': self.id,
                            'res_model_id': self.env['ir.model'].sudo().search([('model', 'like', 'stock.picking')],
                                                                               limit=1).id,
                            'user_id': fm[0] or 1,
                            'summary': self.name,
                        }
                        # add lines
                        self.env['mail.activity'].sudo().create(vals)
                else:
                    # self.sale_type = 'direct_sale'
                    # self.approve_date = date.today()
                    self.action_done()

        return res
