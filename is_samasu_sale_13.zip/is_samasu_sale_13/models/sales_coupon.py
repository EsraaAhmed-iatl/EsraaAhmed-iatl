##############################################################################
#    Description: Sale Customization                                   #
#    Author: IntelliSoft Software                                            #
#    Date: May 2020 -  Till Now                                              #
##############################################################################

from collections import defaultdict
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
import logging
from odoo.exceptions import UserError, AccessError
import pytz
from psycopg2 import sql, extras
from odoo import api, exceptions, fields, models, _
from odoo.tools.misc import clean_context
from odoo.addons.base.models.ir_model import MODULE_UNINSTALL_FLAG
from odoo.tools.safe_eval import safe_eval
from odoo.exceptions import UserError, ValidationError


class ProductTemplate(models.Model):
    _inherit = 'sale.coupon.program'

    expiration = fields.Boolean('Based on Expiration ')

    @api.onchange('expiration','rule_date_from','rule_date_to')
    def _onchange_expiration(self):
        for rec in self:
            if rec.expiration:
                if not (rec.rule_date_to and rec.rule_date_from):
                    raise ValidationError(_('The date must be selected!'))

                products = self.env['stock.production.lot'].search([('removal_date','>=',rec.rule_date_from),('removal_date','<=',rec.rule_date_to),('product_qty','>',0)]).mapped('product_id')
                rec.rule_products_domain = safe_eval(self.rule_products_domain) + [('id', 'in', products.ids)]
            else:
                rec.rule_products_domain = [['sale_ok', '=', True]]








