# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import is_sales
from . import sales_coupon
from . import custom
from . import stock
