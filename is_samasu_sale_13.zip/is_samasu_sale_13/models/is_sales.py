##############################################################################
#    Description: Sale Customization                                   #
#    Author: IntelliSoft Software                                            #
#    Date: May 2020 -  Till Now                                              #
##############################################################################

from collections import defaultdict
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
import logging
from odoo.exceptions import UserError, AccessError, Warning ,ValidationError
import pytz
from psycopg2 import sql, extras
from odoo import api, exceptions, fields, models, _
from odoo.tools.float_utils import float_compare, float_is_zero, float_round
from odoo.tools.misc import clean_context
from odoo.addons.base.models.ir_model import MODULE_UNINSTALL_FLAG
import math
import babel
import time
from odoo import tools

_logger = logging.getLogger(__name__)


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    crm_lead_ids = fields.One2many('crm.lead.line.samasu', 'x_lead_id', 'Lead')
    currency_id = fields.Many2one('res.currency', 'Currency', required=True)
    pricelist_id = fields.Many2one('product.pricelist', string='Pricelist')

    # @api.onchange('currency_id')
    # def onchange_currency(self):
    #     for rec in self:
    #         rec.pricelist_id = rec.env['product.pricelist'].search([('currency_id', '=', rec.currency_id.id)], limit=1).id

    def action_new_quotation(self):
        price_list = self.env['product.pricelist'].search([('currency_id', '=', self.currency_id.id)], limit=1)
        action = self.env.ref("sale_crm.sale_action_quotations_new").read()[0]
        action['context'] = {
            'search_default_opportunity_id': self.id,
            'default_opportunity_id': self.id,
            'search_default_partner_id': self.partner_id.id,
            'default_partner_id': self.partner_id.id,
            'default_team_id': self.team_id.id,
            'default_campaign_id': self.campaign_id.id,
            'default_medium_id': self.medium_id.id,
            'default_origin': self.name,
            'default_source_id': self.source_id.id,
            'default_pricelist_id': price_list.id,
            'default_company_id': self.company_id.id or self.env.company.id,
            'default_order_line': [(0, 0, {
                'product_id': rec.product_id.id,
                'name': rec.name,
                'product_uom': rec.product_uom.id,
                'product_uom_qty': rec.product_uom_qty,
                'price_unit': rec.price_unit,
                'price_subtotal': rec.price_subtotal,
                })for rec in self.crm_lead_ids],
            }
        return action


class CRMLeadSamaSu(models.Model):
    _name = 'crm.lead.line.samasu'

    x_lead_id = fields.Many2one('crm.lead', 'Lead')
    product_id = fields.Many2one('product.product')
    name = fields.Text('Description')
    product_uom = fields.Many2one('uom.uom', 'Unit of Measure')
    product_uom_qty = fields.Float('Qty')
    price_unit = fields.Float('Unit Price')
    price_subtotal = fields.Float('Subtotal', compute='_get_subtotal')

    @api.onchange('product_id', 'product_uom')
    def product_unit_pricessamasu(self):
        for tot in self:
            total_ex_work = 0.0
            genset_ids = self.env['product.genset'].search([('genset_id', '=', tot.product_id.id)], limit=1)
            special_ids = self.env['product.price.list.line'].search([('product_id', '=', tot.product_id.id),
                                                                      ('line_id.customer_id', '=',
                                                                       tot.x_lead_id.partner_id.id)], limit=1)
            # if not tot.x_lead_id.pricelist_id.item_ids:
            if tot.product_uom:
                uom_type = tot.product_uom.uom_type
                if uom_type == 'reference':
                    factor = 1
                elif uom_type == 'bigger':
                    factor = tot.product_uom.factor_inv
                elif uom_type == 'smaller':
                    factor = 1 / tot.product_uom.factor
            if special_ids:
                for line in special_ids:
                    currency_id = tot.x_lead_id.currency_id
                    rate = tot.x_lead_id.currency_id.rate
                    if tot.product_id.id == line.product_id.id:
                        ex_work = line.currency_price * factor
                        currency_genset = line.currency_id
                        rate_genset = line.currency_id.rate
                        if currency_genset != currency_id:
                            x = 1 / rate_genset
                            y = 1 / rate
                            total_rate = (x / y)
                            total_ex_work = ex_work / total_rate
                        if self.x_lead_id.company_id.currency_id == currency_id:
                            total_ex_work = ex_work / rate_genset
                        if currency_genset == currency_id:
                            total_ex_work = ex_work
                        self.price_unit = total_ex_work
            else:
                if genset_ids:
                    for rec in genset_ids:
                        currency_id = tot.x_lead_id.currency_id
                        rate = tot.x_lead_id.currency_id.rate
                        if tot.product_id.id == rec.genset_id.id:
                            ex_work = rec.currency_price * factor
                            currency_genset = rec.currency_id
                            rate_genset = rec.currency_id.rate
                            if currency_genset != currency_id:
                                x = 1 / rate_genset
                                y = 1 / rate
                                total_rate = (x / y)
                                total_ex_work = ex_work / total_rate
                            if self.x_lead_id.company_id.currency_id == currency_id:
                                total_ex_work = ex_work / rate_genset
                            if currency_genset == currency_id:
                                total_ex_work = ex_work
                            self.price_unit = total_ex_work

    @api.onchange('product_id')
    def _onchange_des(self):
        if self.product_id:
            self.name = self.product_id.name
            self.product_uom = self.product_id.uom_id.id

    @api.depends('product_uom_qty', 'price_unit')
    def _get_subtotal(self):
        for rec in self:
            rec.price_subtotal = 0.0
            if rec.product_uom_qty and rec.price_unit:
                rec.price_subtotal = rec.product_uom_qty * rec.price_unit


class ProductMaterial(models.Model):
    _name = 'product.material'
    _rec_name = 'material_no'

    @api.depends('quantity')
    def check_qty(self):
        for rec in self :
            quantity = rec.quantity
            if quantity == 0.0:
               rec.material_qty = False

    name = fields.Char('Name')
    material_no = fields.Char('Material No')
    quantity = fields.Float('Quantity',default=1)
    material_id = fields.Many2one('product.template','Material')
    material_qty = fields.Boolean('Active',default = True,compute="check_qty",store=True)


class DeviceModel(models.Model):
    _name = 'device.model'
    name = fields.Char('Model Name')


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    team_id = fields.Many2one('crm.team','Account')
    device = fields.Boolean('Device')
    model_id = fields.Many2one('device.model', 'Model')
    # material_ids = fields.One2many('product.material','material_id','Material')
    accessories = fields.Boolean('Accessories')
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')


class CrmTeam(models.Model):
    _name = 'crm.team'
    _inherit = 'crm.team'

    discount_target = fields.Float('Discount Target')


class Customers(models.Model):
    _name = 'customers'
    _order = "display_name"
    _description = 'Create Customers File'

    @api.depends('is_company')
    def _compute_company_type(self):
        for partner in self:
            partner.company_type = 'company' if partner.is_company else 'person'

    def _split_street_with_params(self, street_raw, street_format):
        return {'street': street_raw}

    def _write_company_type(self):
        for partner in self:
            partner.is_company = partner.company_type == 'company'

    name = fields.Char(index=True)
    image_128 = fields.Image("Image", max_width=128, max_height=128)
    color = fields.Integer(string='Color Index', default=0)
    company_type = fields.Selection(string='Company Type',
        selection=[('person', 'Individual'), ('company', 'Company')],
        compute='_compute_company_type', inverse='_write_company_type')
    is_company = fields.Boolean(string='Is a Company', default=False,
        help="Check if the contact is a company, otherwise it is a person")
    active = fields.Boolean(default=True)
    website = fields.Char('Website Link')
    parent_id = fields.Many2one('res.partner', string='Related Company', )
    title = fields.Many2one('res.partner.title')
    employee = fields.Boolean(help="Check this box if this contact is an Employee.")
    function = fields.Char(string='Job Position')
    type = fields.Selection(
        [('contact', 'Contact'),
         ('invoice', 'Invoice Address'),
         ('delivery', 'Delivery Address'),
         ('other', 'Other Address'),
         ("private", "Private Address"),
         ], string='Address Type',
        default='contact',
        help="Invoice & Delivery addresses are used in sales orders. Private addresses are only visible by authorized users.")
    street = fields.Char()
    street2 = fields.Char()
    zip = fields.Char(change_default=True)
    city = fields.Char()
    state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict', domain="[('country_id', '=?', country_id)]")
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')
    partner_latitude = fields.Float(string='Geo Latitude', digits=(16, 5))
    partner_longitude = fields.Float(string='Geo Longitude', digits=(16, 5))
    email = fields.Char()
    email_formatted = fields.Char(
        'Formatted Email', compute='_compute_email_formatted',
        help='Format email address "Name <email@domain>"')
    phone = fields.Char()
    mobile = fields.Char()
    comment = fields.Text(string='Notes')
    customer_id = fields.Many2one('customers' ,'Customer',index=True)
    parent_name = fields.Char(related='customer_id.name', readonly=True, string='Parent name')
    child_ids = fields.One2many('customers', 'customer_id', string='Contact', domain=[('active', '=', True)])  # force "active_test" domain to bypass _search() override
    company_id = fields.Many2one('res.company', 'Company', index=True)
    reference = fields.Integer(string='Reference', compute='_compute_customer')
    state = fields.Selection([
        ('draft', 'New'),
        ('send', 'Submit'),
        ('sale_manger', 'Approve Sale Manger'),
    ], string='Status', track_visibility='onchange', help='Status', default='draft')
    display_name = fields.Char(compute='_compute_display_name', store=True, index=True)

    @api.model
    def _search(self, args, offset=0, limit=None, order=None, count=False, access_rights_uid=None):
        """ Override search() to always show inactive children when searching via ``child_of`` operator. The ORM will
        always call search() with a simple domain of the form [('customer_id', 'in', [ids])]. """
        if len(args) == 1 and len(args[0]) == 3 and args[0][:2] == ('customer_id','in') \
                and args[0][2] != [False]:
            self = self.with_context(active_test=False)
        return super(Customers, self)._search(args, offset=offset, limit=limit, order=order,
                                            count=count, access_rights_uid=access_rights_uid)

    def _get_name(self):
        """ Utility method to allow name_get to be overrided without re-browse the partner """
        partner = self
        name = partner.name or ''

        if partner.customer_id:
            if not name and partner.type in ['invoice', 'delivery', 'other']:
                name = dict(self.fields_get(['type'])['type']['selection'])[partner.type]
        if self._context.get('show_address_only'):
            name = partner._display_address(without_company=True)
        if self._context.get('show_address'):
            name = name + "\n" + partner._display_address(without_company=True)
        name = name.replace('\n\n', '\n')
        name = name.replace('\n\n', '\n')
        if self._context.get('address_inline'):
            name = name.replace('\n', ', ')
        if self._context.get('show_email') and partner.email:
            name = "%s <%s>" % (name, partner.email)
        if self._context.get('html_format'):
            name = name.replace('\n', '<br/>')
        if self._context.get('show_vat') and partner.vat:
            name = "%s ‒ %s" % (name, partner.vat)
        return name

    def name_get(self):
        res = []
        for partner in self:
            name = partner._get_name()
            res.append((partner.id, name))
        return res

    @api.depends('is_company', 'name', 'customer_id.name', 'type')
    def _compute_display_name(self):
        diff = dict(show_address=None, show_address_only=None, show_email=None, html_format=None, show_vat=None)
        names = dict(self.with_context(**diff).name_get())
        for partner in self:
            partner.display_name = names.get(partner.id)

    def _compute_customer(self):
        for rec in self:
            ref = self.env['res.partner'].search([('customers_id', '=', self.id)])
            rec.reference = len(ref)

    def action_send(self):
        self.state = 'send'

    def request_sale_manger(self):
        import_obj = self.env['res.partner']
        res_vals = {
            'company_type': self.company_type,
            'name': self.name,
            'phone': self.phone,
            'mobile': self.mobile,
            'email': self.email,
            'website': self.website,
            'city': self.city,
            'street': self.street,
            'street2': self.street2,
            'zip': self.zip,
            'state_id': self.state_id.id,
            'country_id': self.country_id.id,
            'customer_rank': '1',
            'customers_id': self.id,
        }
        request_id = import_obj.create(res_vals)
        child_ids = self.child_ids
        for child in child_ids:
            lines_vals = {
                         'parent_id': request_id.id,
                         'name': child.name,
                          'phone': child.phone,
                          'mobile': child.mobile,
                          'email': child.email,
                          'city': child.city,
                          'street': child.street,
                          'street2': child.street2,
                          'zip': child.zip,
                          'type': child.type,
                          'state_id': child.state_id.id,
                          'country_id': child.country_id.id,
                          'customer_rank': '1',
                          }
            request = import_obj.create(lines_vals)
        self.state = 'sale_manger'


class SaleOrder(models.Model):
    _name = 'sale.order'
    _inherit = 'sale.order'

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        res = {}
        if self.partner_id:
            self.partner_id = self.partner_id.id
            res['domain'] = {'contact_id': [('id', 'in', self.partner_id.child_ids.ids)]}
            return res

    @api.model
    def _get_default_team(self):
        return self.env['crm.team'].search([('member_ids', '=', self.env.user.id)], limit=1).id
        # return self.env['crm.team']._get_default_team_id()

    team_id = fields.Many2one(
        'crm.team', 'Sales Team',
        change_default=True, default=_get_default_team, check_company=True,  # Unrequired company
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id), ('member_ids', 'in', uid)]")
    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('approve_sale', 'Quotation Approve'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
        ], string='Status', readonly=True, copy=False, index=True, tracking=3, default='draft')
    contact_id = fields.Many2one('res.partner', 'Contact')
    bank_id = fields.Many2one('res.partner.bank','Bank Account',domain="[('bank_ids', '=', partner_id.bank_id)]")
    actual_delivery = fields.Date('Actual Delivery', compute='_compute_picking_done', store=True,)
    delivery_state = fields.Selection([
        ('not_delivered', 'Not Delivered'),
        ('delivered', 'Delivered'),
        ('returned', 'Returned'),
        ], string='Delivery Status', copy=False, index=True, default='not_delivered', compute='_compute_picking_done', store=True,)
    approve = fields.Boolean(string='approve', compute='_check_approve_authorty')
    show_approve = fields.Boolean(string='approve', compute='_show_approve')
    approve_position = fields.Many2many('hr.job', string='Approve Position', compute='get_allowed_discount_person')
    # approve_position1 = fields.Many2many('hr.job', string='Approve Position', compute='get_allowed_discount_person')
    total_discount = fields.Float('Total Discount',compute='_get_total_dis')
    approve_gm_lot = fields.Boolean('Approve GM Lot', compute="_compute_approve_gm_lot")
    activity_id = fields.Many2one('mail.activity', string='Activity')
    blocked = fields.Boolean('Blocked')

    @api.depends('order_line.approve_gm')
    def _compute_approve_gm_lot(self):
        self.approve_gm_lot = False
        for rec in self.order_line:
            if rec.approve_gm == True:
                self.approve_gm_lot = True

    @api.depends('picking_ids.state', 'picking_ids.delivery_state', 'picking_ids.actual_delivery')
    def _compute_picking_done(self):
        for order in self:
            order.delivery_state = 'not_delivered'
            pickings = order.picking_ids.filtered(lambda x: x.state == 'done' and x.location_dest_id.usage == 'customer')
            for pic in pickings:
                actual_delivery = pic.actual_delivery
                delivery_state = pic.delivery_state
                order.delivery_state = delivery_state
                order.actual_delivery = actual_delivery
            returned_pickings = order.picking_ids.filtered(
                lambda x: x.state == 'done' and x.location_id.usage == 'customer')
            if returned_pickings:
                order.delivery_state = 'returned'

    @api.model
    def create(self, vals):
        if 'warehouse_id' not in vals and 'company_id' in vals and vals.get('company_id') != self.env.company.id:
            vals['warehouse_id'] = self.env['stock.warehouse'].search([('company_id', '=', vals.get('company_id'))], limit=1).id
        return super(SaleOrder, self).create(vals)

    @api.depends('order_line.discount', 'order_line')
    def _get_total_dis(self):
        total = 0.0
        total_all = 0.0
        total_out_disc = 0.0
        price_subtotal = 0.0
        self.total_out_disc = 0.0
        self.total_discount = 0.0
        for line in self.order_line:
            if line.discount > 0.0:
                total += line.discount
                total_out_disc += line.total_out_disc
                price_subtotal += line.price_subtotal
                if total_out_disc != 0:
                    total_all = (price_subtotal / total_out_disc * 100)
                    if total_all < 100:
                        total_all = 100 - total_all
                    else:
                        total_all = 100
                    self.total_discount = total_all
                else:
                    self.total_discount = 100

    @api.depends('user_id', 'total_discount', 'order_line')
    def get_allowed_discount_person(self):
        for rec in self:
            rec.approve_position = False
            if rec.total_discount == 0.0:
                employee = self.env['hr.employee'].sudo().search([('user_id', '=', rec.user_id.id)], limit=1)
                employee_position = employee.sudo().job_id.id
                rec.approve_position = [(4, employee_position)]
            else:
                today = date.today()
                level_check = self.env['discount.matrix.line'].search([
                    ('matrix_id.date_from', '<=', today), ('matrix_id.date_to', '>=', today),
                    ('min_allowed', '<=', rec.total_discount), ('max_allowed', '>=', rec.total_discount)])
                if level_check:
                    for obj in level_check:
                        rec.approve_position = [(4, obj.position_id.id)]

    @api.depends('user_id')
    def _check_approve_authorty(self):
        for obj in self:
            users = []
            obj.approve = False
            if obj.approve_position:
                employee = self.env['hr.employee'].sudo().search([('user_id', '=', obj.user_id.id)], limit=1)
                employee_position = employee.sudo().job_id.id
                for x in obj.approve_position:
                    filter = self.env['hr.employee'].sudo().search([('job_id', '=', x.id)])
                    for emp in filter:
                        if emp.user_id.id not in users:
                            users.append(emp.user_id.id)
                    if obj.approve_position == employee_position:
                        obj.approve = True
                    else:
                        if self.env.user.id in users:
                            obj.approve = True

    # def _show_approve(self):
    #     for rec in self:
    #         rec.show_approve = False
    #         if rec.state in ['draft', 'sent'] and rec.approve == False and rec.approve_gm_lot == True:
    #             rec.show_approve = True
    #         if rec.state in ['draft', 'sent'] and rec.approve == True and rec.approve_gm_lot == False:
    #             rec.show_approve = True

    def _show_approve(self):
        for rec in self:
            rec.show_approve = False
            if rec.state in ['draft', 'sent'] and rec.approve == True:
                rec.show_approve = True

    def action_approve(self):
        for rec in self.order_line:
            if rec.product_id.type == 'product' and  rec.available == False and rec.blocked == True and rec.blocked_gm == False:
                raise UserError(_('Quantity Item ordered blocked(%s) Place Check Approved Gm.') % (
                rec.product_id.name))
            self.state = 'approve_sale'

    def action_send_gm(self):
        users = self.env['res.groups'].search([('id', '=',
                                                self.env.ref('sales_team.group_sale_manager').id)],
                                              limit=1).users
        self.activity_id.unlink()
        # con_ids = self.search([])
        self.blocked = False
        for rec in self:
            user_id = rec.team_id.user_id.id
            if not user_id:
                raise UserError(_('Please add Team Leader.'))
            for obj in rec.order_line:
                product_id = obj.product_id.name
                vals = {
                    'activity_type_id': self.env['mail.activity.type'].sudo().search(
                        [],
                        limit=1).id,
                    'res_id': rec.id,
                    'res_model_id': self.env['ir.model'].sudo().search([('model', '=', 'sale.order')],
                                                                       limit=1).id,
                    'user_id': user_id,
                    'summary': 'Product Blocked' + product_id,
                }
                self.activity_id = self.env['mail.activity'].sudo().create(vals).id
                self.blocked = True

    def check_limit(self):
        debit = 0.0
        credit = 0.0
        total_check = 0.0
        total = 0.0
        self.ensure_one()
        partner = self.partner_id.id
        credit_limit = self.partner_id.credit_limit
        moveline_obj = self.env['account.move.line']
        movelines = moveline_obj.search(
            [('partner_id', '=', partner),
             ('account_id', '=', self.partner_id.property_account_receivable_id.id)]
        )
        check_safe = self.env['check.safe'].search(
            [('customer_id', '=', partner),
             ('payment_type', '=', 'receive'),
             ('state', '=', 'CO'),
             ]
        )
        if credit_limit > 0.0:
            for line in movelines:
                debit += line.debit
                credit += line.credit
                amount = debit - credit
                total = amount + self.amount_total
            for line2 in check_safe:
                total_check += line2.check_amount
            total = total + total_check
            # if self.pricelist_id.currency_id != self.env.company.currency_id:
            #     total = self.pricelist_id.currency_id.rate
            if total >= credit_limit:
                raise UserError("It is not possible to sell to this customer. The remaining invoices must be paid")

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()
        for order in self:
            order.check_limit()
        return res

    def _prepare_invoice(self):
        """
        Prepare the dict of values to create the new invoice for a sales order. This method may be
        overridden to implement custom invoice generation (making sure to call super() to establish
        a clean extension chain).
        """
        self.ensure_one()
        journal = self.env['account.move'].with_context(force_company=self.company_id.id, default_type='out_invoice')._get_default_journal()
        if not journal:
            raise UserError(_('Please define an accounting sales journal for the company %s (%s).') % (self.company_id.name, self.company_id.id))

        invoice_vals = {
            'ref': self.client_order_ref or '',
            'type': 'out_invoice',
            'narration': self.note,
            'currency_id': self.pricelist_id.currency_id.id,
            'campaign_id': self.campaign_id.id,
            'medium_id': self.medium_id.id,
            'source_id': self.source_id.id,
            'invoice_user_id': self.user_id and self.user_id.id,
            'team_id': self.team_id.id,
            'invoice_partner_bank_id': self.bank_id.id,
            'partner_id': self.partner_invoice_id.id,
            'partner_shipping_id': self.partner_shipping_id.id,
            # 'invoice_partner_bank_id': self.company_id.partner_id.bank_ids[:1].id,
            'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
            'invoice_origin': self.name,
            'invoice_payment_term_id': self.payment_term_id.id,
            'invoice_payment_ref': self.reference,
            'transaction_ids': [(6, 0, self.transaction_ids.ids)],
            'invoice_line_ids': [],
        }
        return invoice_vals


class PaymentTerm(models.Model):
    _name = 'payment.term'

    name = fields.Char('Name')
    date = fields.Date('Date', default=fields.Date.today())
    description = fields.Html('Description')
    team_id = fields.Many2one('crm.team', 'Account')
    payment_id = fields.Many2one('account.payment.term', 'Term')
    user_id = fields.Many2one('res.users', string='User', default=lambda self: self.env.user,readonly="1")
    state = fields.Selection([
        ('draft', 'New'),
        ('send', 'Submit'),
        ('sale_manger', 'Approve Sale Manger'),
        ('account', 'Approve Account'),
    ], string='Status', track_visibility='onchange', help='Status', default='draft')

    def request(self):
        self.state = 'send'

    def request_sale_manger(self):
        self.state = 'sale_manger'

    def request_account(self):
        self.state = 'account'


class AccountPaymentTerm(models.Model):
    _name = 'account.payment.term'
    _inherit = 'account.payment.term'

    team_id = fields.Many2one('crm.team', 'Account')
    count_percent = fields.Float('Percent')


class SaleOrderLine(models.Model):
    _name = 'sale.order.line'
    _inherit = 'sale.order.line'

    total_out_disc = fields.Float('Total Out Disc', compute="_compute_total_out_disc")

    @api.depends('price_unit', 'product_uom_qty')
    def _compute_total_out_disc(self):
        for rec in self:
            rec.total_out_disc = 0.0
            if rec.price_unit and rec.product_uom_qty:
                rec.total_out_disc = rec.product_uom_qty * rec.price_unit

    @api.onchange('product_id')
    def product_id_change(self):
        if not self.product_id:
            return
        valid_values = self.product_id.product_tmpl_id.valid_product_template_attribute_line_ids.product_template_value_ids
        # remove the is_custom values that don't belong to this template
        for pacv in self.product_custom_attribute_value_ids:
            if pacv.custom_product_template_attribute_value_id not in valid_values:
                self.product_custom_attribute_value_ids -= pacv

        # remove the no_variant attributes that don't belong to this template
        for ptav in self.product_no_variant_attribute_value_ids:
            if ptav._origin not in valid_values:
                self.product_no_variant_attribute_value_ids -= ptav

        vals = {}
        if not self.product_uom or (self.product_id.uom_id.id != self.product_uom.id):
            vals['product_uom'] = self.product_id.uom_id
            vals['product_uom_qty'] = self.product_uom_qty or 1.0

        product = self.product_id.with_context(
            lang=self.order_id.partner_id.lang,
            partner=self.order_id.partner_id,
            quantity=vals.get('product_uom_qty') or self.product_uom_qty,
            date=self.order_id.date_order,
            pricelist=self.order_id.pricelist_id.id,
            uom=self.product_uom.id
        )

        vals.update(name=self.get_sale_order_line_multiline_description_sale(product))
        if self.order_id.partner_id.customer_vat:
            self._compute_tax_id()

        if self.order_id.pricelist_id and self.order_id.partner_id:
            vals['price_unit'] = self.env['account.tax']._fix_tax_included_price_company(
                self._get_display_price(product), product.taxes_id, self.tax_id, self.company_id)
        self.update(vals)

        title = False
        message = False
        result = {}
        warning = {}
        if product.sale_line_warn != 'no-message':
            title = _("Warning for %s") % product.name
            message = product.sale_line_warn_msg
            warning['title'] = title
            warning['message'] = message
            result = {'warning': warning}
            if product.sale_line_warn == 'block':
                self.product_id = False

        return result

    order_id = fields.Many2one('sale.order', string='Order Reference',required=False, ondelete='cascade', index=True, copy=False)
    product_id = fields.Many2one(
        'product.product', string='Product', domain="[('sale_ok', '=', True)]",required=False
       )
    # material_id = fields.Many2one('product.material','Material', domain="[('quantity', '>', 0.0)]")
    lot_id = fields.Many2one('stock.production.lot', 'Lots/Serial Numbers', domain="[('product_id', '=', product_id)]")
    free = fields.Boolean('Free')
    approve_gm = fields.Boolean('Approve GM', compute="_def_approve_gm")
    available = fields.Boolean(string='Available', compute='compute_product_available')
    blocked = fields.Boolean(string='Blocked', compute='compute_product_available')
    blocked_gm = fields.Boolean(string='Blocked')
    serial = fields.Boolean(string='Serial')

    @api.depends('lot_id')
    def _def_approve_gm(self):
        self.approve_gm = False
        for obj in self:
            lot_id = obj.lot_id
            warehouse = self.env['stock.quant'].search(
                [('product_id', '=', obj.product_id.id), ('inventory_quantity', '>', 0.0)], order='removal_date', limit=1)
            for rec in warehouse:
                lot = rec.lot_id
                if lot != lot_id:
                    obj.approve_gm = True
                if lot == lot_id:
                    obj.approve_gm = False

    @api.depends('product_id', 'product_uom', 'route_id', 'product_uom_qty')
    def compute_product_available(self):
        self.available = False
        self.blocked = False
        for rec in self:
            if rec.product_id.type == 'product':
                items_blocking = self.env['stock.warehouse.orderpoint'].search([('product_id', '=', rec.product_id.id)])
                if not items_blocking:
                    precision = self.env['decimal.precision'].precision_get('Product Unit of Measure')
                    product_qty = rec.product_uom._compute_quantity(rec.product_uom_qty, rec.product_id.uom_id)
                    if float_compare(rec.product_id.virtual_available, product_qty, precision_digits=precision) == -1:
                        rec.available = False
                    else:
                        rec.available = True
                else:
                    for item in items_blocking:
                        blocked_qty = item.qty_blocked
                        precision = self.env['decimal.precision'].precision_get('Product Unit of Measure')
                        product_qty = rec.product_uom._compute_quantity(rec.product_uom_qty, rec.product_id.uom_id)
                        if float_compare(rec.product_id.virtual_available - blocked_qty, product_qty, precision_digits=precision) == -1:
                            rec.available = False
                            if blocked_qty > 0.0:
                                rec.blocked = True
                        else:
                            rec.available = True
                            rec.blocked = False
            elif rec.product_id.type == 'service':
                rec.available = True

    @api.onchange('free')
    def product_free(self):
        free = self.free
        if free == True:
            self.price_unit = 0.0

    @api.depends('product_id', 'product_uom')
    def product_unit_pricessamasu(self):
        for tot in self:
            total_ex_work = 0.0
            genset_ids = self.env['product.genset'].search([('genset_id', '=', tot.product_id.id)], limit=1)
            special_ids = self.env['product.price.list.line'].search([('product_id', '=', tot.product_id.id),
                                                                      ('line_id.customer_id', '=', tot.order_id.partner_id.id)], limit=1)
            if not tot.order_id.pricelist_id.item_ids:
                if tot.product_uom:
                    uom_type = tot.product_uom.uom_type
                    if uom_type == 'reference':
                        factor = 1
                    elif uom_type == 'bigger':
                        factor = tot.product_uom.factor_inv
                    elif uom_type == 'smaller':
                        factor = 1 / tot.product_uom.factor
                if special_ids:
                    for line in special_ids:
                        currency_id = tot.order_id.pricelist_id.currency_id
                        rate = tot.order_id.pricelist_id.currency_id.rate
                        if tot.product_id.id == line.product_id.id:
                            ex_work = line.currency_price * factor
                            currency_genset = line.currency_id
                            rate_genset = line.currency_id.rate
                            if currency_genset != currency_id:
                                x = 1 / rate_genset
                                y = 1 / rate
                                total_rate = (x / y)
                                total_ex_work = ex_work / total_rate
                            if self.order_id.company_id.currency_id == currency_id:
                                total_ex_work = ex_work / rate_genset
                            if currency_genset == currency_id:
                                total_ex_work = ex_work
                            self.price_unit = total_ex_work
                else:
                    if genset_ids:
                        for rec in genset_ids:
                            currency_id = tot.order_id.pricelist_id.currency_id
                            rate = tot.order_id.pricelist_id.currency_id.rate
                            if tot.product_id.id == rec.genset_id.id:
                                ex_work = rec.currency_price * factor
                                currency_genset = rec.currency_id
                                rate_genset = rec.currency_id.rate
                                if currency_genset != currency_id:
                                    x = 1 / rate_genset
                                    y = 1 / rate
                                    total_rate = (x / y)
                                    total_ex_work = ex_work / total_rate
                                if self.order_id.company_id.currency_id == currency_id:
                                    total_ex_work = ex_work / rate_genset
                                if currency_genset == currency_id:
                                    total_ex_work = ex_work
                                self.price_unit = total_ex_work

    @api.onchange('product_uom', 'product_uom_qty')
    def product_uom_change(self):
        count_percent = self.order_id.payment_term_id.count_percent
        price_unit = self.price_unit
        cost = (price_unit * count_percent) / 100 + price_unit
        if not self.product_uom or not self.product_id:
            self.price_unit = 0.0
            return
        if self.order_id.pricelist_id and self.order_id.partner_id:
            product = self.product_id.with_context(
                lang=self.order_id.partner_id.lang,
                partner=self.order_id.partner_id,
                quantity=self.product_uom_qty,
                date=self.order_id.date_order,
                pricelist=self.order_id.pricelist_id.id,
                uom=self.product_uom.id,
                fiscal_position=self.env.context.get('fiscal_position')
            )
            self.price_unit = cost

    @api.onchange('product_id')
    def _onchange_lot_id(self):
        self.serial = False
        for rec in self:
            if rec.product_id.tracking == 'lot':
                user_id = rec.order_id.team_id.user_id.id
                if not user_id:
                    raise UserError(_('Please add Team Leader.'))
                product_id = rec.product_id.name
                vals = {
                    'activity_type_id': self.env['mail.activity.type'].sudo().search(
                        [],
                        limit=1).id,
                    'res_id': rec.id,
                    'res_model_id': self.env['ir.model'].sudo().search([('model', '=', 'sale.order')],
                                                                       limit=1).id,
                    'user_id': user_id,
                    'summary': 'Chang Serial NO ',
                }
                # self.activity_id = self.env['mail.activity'].sudo().create(vals).id
                self.serial = True
            lot_id = 0.0
            for res in self:
                warehouse = self.env['stock.quant'].search([('product_id', '=', res.product_id.id), ('inventory_quantity', '>', 0.0)],order='removal_date',limit=1)
                for rec in warehouse:
                    lot_id = rec.lot_id.id
                self.lot_id = lot_id
        # con_ids = self.search([])


class StockWarehouseOrderpoint(models.Model):
    _name = 'stock.warehouse.orderpoint'
    _inherit = 'stock.warehouse.orderpoint'

    qty_blocked = fields.Float('Qty Blocked')


class ResPartner(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'

    team_id = fields.Many2one('crm.team', string="Account")
    customers_id = fields.Many2one('customers', 'Customers')
    sector_id = fields.Many2one('partner.sector', 'Sector')


class PartnerSector(models.Model):
    _name = 'partner.sector'

    name = fields.Char('Name')


class VisitPurpose(models.Model):
    _name = 'visit.purpose'
    _description = 'A model for Visit Purpose'

    name = fields.Char('Name')


class ActivityLine(models.Model):
    _name = 'activity.line'
    _description = 'A model for activity Line.'
    _rec_name = 'purpose_id'

    name = fields.Char('Customer (Text)')
    line_id = fields.Many2one('activity', string='Activity')
    scheduled_date = fields.Datetime('Schedule Date')
    purpose_id = fields.Many2one('visit.purpose', 'Purpose')
    engineer_id = fields.Many2one('res.users', 'Assign To', related='line_id.engineer_id', store=True)
    contact_id = fields.Many2one('res.partner', 'Contact(Doctor)')
    partner_id = fields.Many2one('res.partner', 'Customer(Hospital)')
    phone = fields.Float('Phone')
    date_done = fields.Datetime('Date Done')
    date = fields.Datetime('Date')
    note = fields.Text('Reason')
    cost = fields.Float('Cost')
    reject = fields.Boolean('Reject')
    pending = fields.Boolean('Pending')
    done = fields.Boolean('Done')
    state = fields.Selection([
        ('done', 'Done'),
        ('pending', 'Pending'),
    ], string='Status', track_visibility='onchange', help='Status of the activity')

    @api.onchange('pending','done')
    def onchange_state(self):
        for rec in self:
            if rec.pending == True:
                rec.state = 'pending'
            if rec.done == True:
                rec.state = 'done'

    @api.onchange('state')
    def onchange_x(self):
        for rec in self:
            if rec.state == 'done':
                rec.date_done = default = fields.Datetime.today()
            if rec.state == 'pending':
                warning_mess = {
                    'title': _('Warning!'),
                    'message': _('Please Enter the Reason and Date Of Pending.')
                }
                return {'warning': warning_mess}


class Activity(models.Model):
    _name = 'activity'
    _description = 'A model for activity.'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    @api.model
    def _get_default_team(self):
        return self.env['crm.team']._get_default_team_id()

    name = fields.Char('Name')
    achievement_percent = fields.Float('Achievement', compute="_pef_percent")
    activity_id = fields.Many2one('mail.activity', string='Activity')
    user_id = fields.Many2one('res.users', string='User', default=lambda self: self.env.user,readonly="1")
    team_id = fields.Many2one('crm.team', default=_get_default_team)
    line_ids = fields.One2many('activity.line', 'line_id', 'Line')
    date_order = fields.Date('Date Order', default=fields.Date.today())
    date_from = fields.Date('Date From')
    date_to = fields.Date('Date To')
    engineer_id = fields.Many2one('res.users', 'Assign To')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('assign', 'Assigned'),
        ('open', 'Open'),
        ('reject', 'Reject'),
        ('close', 'Close'),
    ], string='Status', track_visibility='onchange', help='Status of the activity',default="draft")

    def action_assign(self):
        users = self.env['res.groups'].search([('id', '=',
                                                self.env.ref('sales_team.group_sale_salesman').id)],
                                              limit=1).users
        self.activity_id.unlink()
        engineer_id = self.engineer_id.id
        for obj in self.line_ids:
            purpose_id = obj.purpose_id.name
            if not purpose_id :
                raise UserError(_('Please add purpose activity .'))
            for user in users:
                vals = {
                    'activity_type_id': self.env['mail.activity.type'].sudo().search(
                        [],
                        limit=1).id,
                    'res_id': self.id,
                    'res_model_id': self.env['ir.model'].sudo().search([('model', '=', 'activity')],
                                                                       limit=1).id,
                    'user_id': engineer_id,
                    'summary': 'Job' + purpose_id,
                }
            self.activity_id = self.env['mail.activity'].sudo().create(vals).id
        self.state = 'assign'

    @api.depends('line_ids.done')
    def _pef_percent(self):
        for rec in self:
            count_line = len(rec.line_ids)
            line_done = self.env['activity.line'].search([('done', '=', True), ('line_id', '=', rec.id)])
            count_line_done = len(line_done)
            if count_line_done > 0.0:
                rec.achievement_percent = (count_line_done / count_line)*100
            else:
                rec.achievement_percent = 0.0

    def action_open(self):
        self.state = 'open'

    def action_reject(self):
        self.state = 'reject'

    def action_close(self):
        self.state = 'close'

    @api.model
    def compute_mail_activity(self):
        users = self.env['res.groups'].search([('id', '=',
                                                self.env.ref('sales_team.group_sale_salesman').id)],
                                              limit=1).users

        # schedule activity for manager(s) to auditor
        self.activity_id.unlink()
        con_ids = self.search([])
        for rec in con_ids:
            engineer_id = rec.engineer_id.id
            str_now = datetime.now().date()
            for obj in rec.line_ids:
                scheduled_date = obj.scheduled_date.date()
                purpose_id = obj.purpose_id.name
                if scheduled_date:
                    # date_deadline = datetime.strptime(str(obj.scheduled_date), '%Y-%m-%d').date()
                    days = (scheduled_date - str_now).days
                    if days == 1:
                        for user in users:
                            vals = {
                                'activity_type_id': self.env['mail.activity.type'].sudo().search(
                                    [],
                                    limit=1).id,
                                'res_id': rec.id,
                                'res_model_id': self.env['ir.model'].sudo().search([('model', '=', 'activity')],
                                                                                   limit=1).id,
                                'user_id': engineer_id,
                                'summary': 'Visit T' + purpose_id,
                            }
                        self.activity_id = self.env['mail.activity'].sudo().create(vals).id


class DiscountMatrix(models.Model):
    _name = 'discount.matrix'
    _inherit = ['mail.thread']

    name = fields.Char('Reference', required=True)
    date_from = fields.Date(string='Date From',  required=True,
        default=lambda self: fields.Date.to_string(date.today().replace(day=1)))
    date_to = fields.Date(string='Date To', required=True,
        default=lambda self: fields.Date.to_string((datetime.now() + relativedelta(months=+1, day=1, days=-1)).date()))
    level_line_ids = fields.One2many('discount.matrix.line', 'matrix_id', 'Levels')
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env['res.company']._company_default_get('discount.matrix'))

    @api.onchange('date_from', 'date_to')
    def get_date(self):
        for x in self:
            if x.date_to and x.date_from:
                ttyme = datetime.fromtimestamp(time.mktime(time.strptime(str(x.date_from), "%Y-%m-%d")))
                ttyme2 = datetime.fromtimestamp(time.mktime(time.strptime(str(x.date_to), "%Y-%m-%d")))
                locale = self.env.context.get('lang', 'en_US')
                x.name = 'Discount Matrix From ' + ' ' + tools.ustr(babel.dates.format_date(date=ttyme, format='MMMM-y', locale=locale)) + ' ' + 'To' + ' ' + tools.ustr(babel.dates.format_date(date=ttyme2, format='MMMM-y', locale=locale))

    _sql_constraints = [
        ('name_uniq', 'unique (name)', "Discount Matrix Already Exists In This Period!"),
    ]


class SaleAdvancePaymentInv(models.TransientModel):
    _name = "sale.advance.payment.inv"
    _inherit = ['sale.advance.payment.inv']
    _description = "Sales Advance Payment Invoice"

    def _prepare_so_line(self, order, analytic_tag_ids, tax_ids, amount):
        so_values = {
            'name': _('Down Payment: %s') % (time.strftime('%m %Y'),),
            'price_unit': amount,
            'product_uom_qty': 0.0,
            'order_id': order.id,
            'discount': 0.0,
            'product_uom': self.product_id.uom_id.id,
            'product_id': self.product_id.id,
            'analytic_tag_ids': analytic_tag_ids,
            'tax_id': [(6, 0, tax_ids)],
            'is_downpayment': True,
        }
        return so_values

    def _prepare_invoice_values(self, order, name, amount, so_line):
        invoice_vals = {
            'type': 'out_invoice',
            'invoice_origin': order.name,
            'invoice_user_id': order.user_id.id,
            'narration': order.note,
            'partner_id': order.partner_invoice_id.id,
            'fiscal_position_id': order.fiscal_position_id.id or order.partner_id.property_account_position_id.id,
            'partner_shipping_id': order.partner_shipping_id.id,
            'currency_id': order.pricelist_id.currency_id.id,
            'invoice_payment_ref': order.client_order_ref,
            'invoice_payment_term_id': order.payment_term_id.id,
            'invoice_partner_bank_id': order.bank_id.id,
            'team_id': order.team_id.id,
            'campaign_id': order.campaign_id.id,
            'medium_id': order.medium_id.id,
            'source_id': order.source_id.id,
            'invoice_line_ids': [(0, 0, {
                'name': name,
                'price_unit': amount,
                'quantity': 1.0,
                'product_id': self.product_id.id,
                'product_uom_id': so_line.product_uom.id,
                'tax_ids': [(6, 0, so_line.tax_id.ids)],
                'sale_line_ids': [(6, 0, [so_line.id])],
                'analytic_tag_ids': [(6, 0, so_line.analytic_tag_ids.ids)],
                'analytic_account_id': order.analytic_account_id.id or False,
            })],
        }

        return invoice_vals

    def _prepare_invoice_line(self):
        """
        Prepare the dict of values to create the new invoice line for a sales order line.

        :param qty: float quantity to invoice
        """
        self.ensure_one()
        return {
            'display_type': self.display_type,
            'sequence': self.sequence,
            'name': self.name,
            'product_id': self.product_id.id,
            'product_uom_id': self.product_uom.id,
            'quantity': self.qty_to_invoice,
            'discount': self.discount,
            'price_unit': self.price_unit,
            'tax_ids': [(6, 0, self.tax_id.ids)],
            'analytic_account_id': self.order_id.analytic_account_id.id,
            'analytic_tag_ids': [(6, 0, self.analytic_tag_ids.ids)],
            'sale_line_ids': [(4, self.id)],
        }


class DiscountMatrixLine (models.Model):
    _name = 'discount.matrix.line'
    _inherit = ['mail.thread']
    _rec_name = 'position_id'

    @api.constrains('name', 'position_id')
    def _check_position_level(self):
        for level in self :
            level_check = self.env['discount.matrix.line'].search([
                ('matrix_id', '=', level.matrix_id.id),
                ('name', '=', level.name),('position_id', '=', level.position_id.id),
                ('id', '!=', level.id),
            ])
            if level.name and level.position_id and level_check:
                raise ValidationError(_("this position is already have level."))

    name = fields.Char(string='Discount Level', track_visibility='onchange')
    position_id = fields.Many2one('hr.job', 'Jop Position', required=True)
    min_allowed = fields.Float(string='Min Allowed Discount (%) ', required=True, track_visibility='onchange')
    max_allowed = fields.Float(string='Max Allowed Discount (%) ', required=True, track_visibility='onchange')
    matrix_id = fields.Many2one('discount.matrix', 'Discount Matrix')
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env['res.company']._company_default_get('discount.matrix.line'))

# class PurchaseOrderLine(models.Model):
#     _name = 'purchase.order.line'
#     _inherit = 'purchase.order.line'
#
#     def _prepare_stock_moves(self, picking):
#         res = super(PurchaseOrderLine, self)._prepare_stock_moves(picking)
#         for re in res:
#             re['material_no'] = self.product_id.default_code
#         return res
