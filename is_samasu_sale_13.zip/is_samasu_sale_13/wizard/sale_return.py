from odoo import api, fields, models, _
from odoo.exceptions import UserError


class ReturnPicking(models.TransientModel):
    _inherit = "stock.return.picking"

    def _create_returns(self):
        # return wizard cannot hold few lines for one move the implementation of
        # stock_account will raise singltone error, to propagate lot_id we are
        # mapping moves between pickings after move was created
        res = super()._create_returns()
        picking_returned = self.env["stock.picking"].browse(res[0])
        ml_ids_to_update = picking_returned.move_line_ids.ids
        moves_with_lot = self.product_return_moves.mapped(
            "move_id.move_line_ids"
        ).filtered(lambda l: l.lot_id)
        for line in moves_with_lot:
            ml = fields.first(
                picking_returned.move_line_ids.filtered(
                    lambda l: l.product_id == line.product_id
                    and l.id in ml_ids_to_update
                )
            )
            if ml and not ml.lot_id and (ml.product_uom_qty == line.qty_done):
                ml.lot_id = line.lot_id
            ml_ids_to_update.remove(ml.id)
        return res

    # def _prepare_move_default_values(self, return_line, new_picking):
    #     res = super(ReturnPicking, self)._prepare_move_default_values( return_line, new_picking)
    #     print("****************************",res)
    #     print('vvvvvvvvvvv',return_line)
    #     print('hjkjh',self.move_id.origin_returned_move_id)
    #     # res['move_line_ids'] = return_line.move_id.move_line_ids.ids
    #     return res

    # @api.model
    # def _prepare_stock_return_picking_line_vals_from_move(self, stock_move):
    #    res = super(ReturnPicking, self)._prepare_stock_return_picking_line_vals_from_move(stock_move)
    #    print("****************************",res)
    #    move= self.product_return_moves.move_id.name
    #    print('ssssssss',move )
    #    # res['lot_id'] = stock_move.move_line_nosuggest_ids[0].lot_id.id
    #    return res