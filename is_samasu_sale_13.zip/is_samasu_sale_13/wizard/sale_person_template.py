
# -*- coding: utf-8 -*-
from odoo import api, models, fields
from odoo.tools import float_round
from odoo.exceptions import UserError, Warning
from datetime import datetime


class SalePersonReport(models.AbstractModel):
    _name = 'report.is_samasu_sale_13.sale_person_pdf_report'

    def _get_header_info(self, data):
        date_from = data['from_date']
        date_to = data['date_to']

        return {
            'start_date': date_from,
            'date_to': date_to,
            'today': datetime.now().date(),
        }

    def _get_data_from_report(self, data):
        active_ids = self._context.get('active_ids')
        pdf = self.env['sale.person.pdf'].browse(active_ids)
        for rec in pdf:
            date_from = rec.from_date
            date_to = rec.date_to
            user_id = rec.user_id.id
        res = []
        obj = self.env['sale.order.line'].search([('order_id.date_order', '>=', date_from),('order_id.date_order', '<=', date_to),('order_id.user_id', '=', user_id)])
        for object in obj:
            partner_id = object.order_id.partner_id.name
            product_id = object.product_id.name
            product_uom = object.product_uom.name
            material_id = object.material_id.material_no
            product_uom_qty = object.product_uom_qty
            price_unit = object.price_unit
            tax_id = object.tax_id.name
            price_subtotal = object.price_subtotal
            res.append({'product_id': product_id,'partner_id':partner_id,'material_id':material_id,'product_uom_qty':product_uom_qty,
                        'product_uom': product_uom,'price_unit': price_unit,'tax_id': tax_id,'price_subtotal':price_subtotal})
        return res

    @api.model
    def _get_report_values(self, docids, data=None):
        data['records'] = self.env['sale.order.line'].browse(data)
        docs = data['records']
        sales_details_report = self.env['ir.actions.report']._get_report_from_name('is_samasu_sale_13.sale_person_pdf_report')
        docargs = {

            'data': data,
            'docs': docs,
        }
        return {
            'doc_ids': self.ids,
            'doc_model': sales_details_report.model,
            'docs': data,
            'get_data_from_report': self._get_data_from_report(data),
            'get_header_info': self._get_header_info(data),

        }
