
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError



class StockSearch(models.TransientModel):
    _name = 'stock.search'

    text = fields.Char('Enter Search Text',required=True)

    def find(self):
        tree_view_id = self.env.ref('product.product_template_tree_view').id
        form_view_id = self.env.ref('product.product_template_only_form_view').id
        oe_search_result=[]
        # Name Search
        product_names = self.env['product.template'].search([('name','ilike',self.text)])
        if product_names:
            for name in product_names:
                oe_search_result.append(name.id)

        product_ref = self.env['product.template'].search([('default_code', 'ilike', self.text)])
        if product_ref:
            for ref in product_ref:
                oe_search_result.append(ref.id)
        product_alternatives = self.env['product.template'].search([('material_ids.material_no', 'ilike', self.text)])
        if product_alternatives:
            for alter in product_alternatives:
                oe_search_result.append(alter.id)

        return {
            'type': 'ir.actions.act_window',
            'views': [(tree_view_id, 'tree'), (form_view_id, 'form')],
            'view_id': tree_view_id,
            'view_mode': 'tree,form',
            'name': _('Products'),
            'res_model': 'product.template',
            'domain': [('id', 'in', oe_search_result)],
            'context': self.env.context,
            'target': 'current',
            'nodestroy': True
        }

