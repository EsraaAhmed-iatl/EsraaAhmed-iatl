# -*- coding: utf-8 -*-

import time
from odoo import api, fields, models, _
from odoo.exceptions import UserError
import datetime


class SalePersonPDF(models.TransientModel):
    _name = 'sale.person.pdf'

    from_date = fields.Date('Date From', required=True)
    date_to = fields.Date('Date To', required=True)
    user_id = fields.Many2one('res.users','Sales person', required=True)



    def print_report(self):
        data = {}
        res = {}
        if self.from_date and self.user_id:
            line_ids = self.env['sale.order.line'].search(
                [('order_id.date_order', '>=', self.from_date), ('order_id.date_order', '<=', self.date_to), ('order_id.user_id', '=', self.user_id.id),
                 ]).mapped('id')

        data['from_date'] = self.from_date
        data['date_to'] = self.date_to
        data['user_id'] = self.user_id.name
        return self.env.ref('is_samasu_sale_13.report_sale_person_id').report_action([], data=data)
