# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'SAMASU Sales Customization',
    'version': '1.1',
    'author': 'Intellisoft Software',
    'summary': 'Sales Module',
    'description': """
This module allows you to manage your Sale.
===========================================================

Easily manage receipts and delivery orders , Control Products and all operations are stock moves between locations.""",

    'website': 'http://www.intellisoft.sd',
    'images': ['static/description/icon.png'],
    'depends': ['mail', 'sale_management', 'stock', 'crm', 'sale_coupon', 'hr', 'analytic'],
    'sequence': 13,
    'data': [

        'security/sale_security.xml',
        'security/ir.model.access.csv',
        # 'data/diesel_sequence.xml',
        'data/scheduled_actions.xml',
        # 'views/general_view.xml',
        # 'views/stock_view.xml',
        # 'wizard/check_qty_views.xml',
        # 'wizard/add_kit_views.xml',
        # 'wizard/customer_sale_order.xml',
        'views/report.xml',
        'views/sales_view.xml',
        'views/stock_view.xml',
        'views/sales_report_templates.xml',
        'views/crm_view.xml',
        'views/sales_coupon_view.xml',
        'views/custom_view.xml',
        'wizard/sale_person_template_view.xml',
        'wizard/sale_person_view.xml',
        'wizard/stock_search_views.xml',
        # reports


    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
