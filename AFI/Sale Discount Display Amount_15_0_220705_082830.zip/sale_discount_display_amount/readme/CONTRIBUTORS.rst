* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Abraham Anes <abrahamanes@gmail.com>
* Chafique Delli <chafique.delli@akretion.com>
* Ruchir Shukla <ruchir@bizzappdev.com>
* Manuel Regidor <manuel.regidor@sygel.es>
