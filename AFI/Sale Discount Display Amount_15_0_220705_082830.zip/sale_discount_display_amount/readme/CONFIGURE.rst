To configure this module, you need to:

#. Go to Sales/Settings and check "Allow discounts on sales order lines"
