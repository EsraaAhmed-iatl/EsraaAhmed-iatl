# -*- coding: utf-8 -*-
from datetime import datetime, date
# from datetime import date
from decimal import Decimal

# import vals as vals
from dateutil.relativedelta import relativedelta

from odoo.exceptions import ValidationError
from odoo.exceptions import UserError, ValidationError

from odoo import models, fields, api, _

STATE = [
    ('draft', 'Draft'),
    ('supervisor_direct_manager', 'Waiting Department Manager Approval'),
    ('hr_department', 'Waiting HR Department Approval'),
    ('waiting_gm_approve',  'Waiting General Manager Approval'),
    ('waiting_f_approve',  'Waiting Financial Approval'),
    ('done', 'Done'),
]
class Employee(models.Model):
    """"""
    _inherit = 'hr.employee'

    overtime_hours_rate = fields.Integer('Overtime Hours Rate')

class OvertimeRequest(models.Model):
    _name = 'overtime.request'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Overtime Request"
    _rec_name = 'name_seq'

    def notification(self, group):
        self.acvtivity_id.unlink()
        for rec in self:
            group_department = self.env.ref(group).id
           
            self.env.cr.execute(
                '''SELECT uid FROM res_groups_users_rel WHERE gid = %s order by uid''' % (
                    group_department))

            #         # schedule activity for user(s) to approve
            for fm in list(filter(lambda x: (
                    self.env['res.users'].sudo().search([('id', '=', x), ('company_id', '=', self.company_id.id)])),
                                  self.env.cr.fetchall())):
                print('========fm', fm)
                vals = {
                    'activity_type_id': self.env['mail.activity.type'].sudo().search(
                        [('name', 'like', u'Call')],
                        limit=1).id,
                    # 'res_id': self.check_ids[0]  ,
                    'res_id': self.id,
                    'res_model_id': self.env['ir.model'].sudo().search(
                        [('model', 'like', 'overtime.request')], limit=1).id,
                    'user_id': fm[0] or 1,
                    'summary': u'New Overtime Request Approve ',
                }
                print('===============vals', vals)

                #             # add lines
                acvtivity_id = self.env['mail.activity'].sudo().create(vals)

    def button_draft(self):
        self.state = 'supervisor_direct_manager'

    def button_direct_approve(self):
        self.state = 'hr_department'
        self.notification('hr.group_hr_manager')

    def button_hr_department(self):
        vals = {
            'activity_type_id': self.env['mail.activity.type'].sudo().search(
                [('name', 'like', u'Call')],
                limit=1).id,
            'res_id': self.id,
            'res_model_id': self.env['ir.model'].sudo().search(
                [('model', 'like', 'overtime.request')], limit=1).id,
            'user_id': self.create_uid.id,
            'summary': u'New Overtime Request Approve ',
        }
        # add lines
        acvtivity_id = self.env['mail.activity'].sudo().create(vals)
        self.state = 'waiting_gm_approve'

    def button_direct_hr(self):
        self.state = 'hr'
        self.notification('hr.group_hr_manager')

    def button_done(self):
        vals = {
            'activity_type_id': self.env['mail.activity.type'].sudo().search(
                [('name', 'like', u'Call')],
                limit=1).id,
            'res_id': self.id,
            'res_model_id': self.env['ir.model'].sudo().search(
                [('model', 'like', 'overtime.request')], limit=1).id,
            'user_id': self.create_uid.id,
            'summary': u'New Overtime Request Approve ' + self.name_seq,
        }
        acvtivity_id = self.env['mail.activity'].sudo().create(vals)

        if self.company_id.overtime_type == 'receipt':
            for rec in self:
                if not rec.company_id.account_id:
                    raise UserError(_("Please select an account"))

                if not rec.company_id.journal_id:
                    raise UserError(_("please select journal "))    

                move_id = self.env['account.move'].sudo().create([
                    {
                        'date': rec.overtime_date,
                        'partner_id': rec.employee_id.address_home_id.id,
                        'journal_id': rec.company_id.journal_id.id,
                        'move_type': 'in_receipt',
                        'line_ids': [
                            (0, 0, {
                                'name': rec.name_seq,
                                'partner_id': rec.employee_id.address_home_id.id,
                                'account_id': rec.company_id.account_id.id,
                                'analytic_account_id': rec.department_id.analytic_account_id.id,
                                'price_unit': rec.total_amount,
                                'debit': rec.total_amount,
                            }
                             ),
                            (0, 0, {
                                'name': rec.name_seq,
                                'partner_id': rec.employee_id.address_home_id.id,
                                'account_id': rec.employee_id.address_home_id.property_account_payable_id.id,
                                'price_unit': rec.total_amount,
                                'credit': rec.total_amount,
                                'analytic_account_id': rec.department_id.analytic_account_id.id,
                                'account_internal_type': 'payable',
                                'exclude_from_invoice_tab': True
                            }
                             ), ], }])

                self.write({'state': 'done', 'move_id': move_id.id})

        if self.company_id.overtime_type == 'payroll':
            self.write({'state': 'done', })
       

    def button_waiting_f_approve(self):
        self.state = 'waiting_f_approve'
       

    def _employee_get(self):
        record = self.env['hr.employee'].search([('user_id', '=', self.env.user.login)], limit=1)
        return record

    # def get_dept(self):
    #     for rec in self:
    #         if rec.employee_id:
    #             rec.department_id = rec.employee_id.department_id.id

    @api.model
    def create(self, vals):
        if vals.get('name_seq', _('New')) == _('New'):
            vals['name_seq'] = self.env['ir.sequence'].next_by_code('employee.overtime.sequence') or _('New')
        result = super(OvertimeRequest, self).create(vals)
        return result

    name_seq = fields.Char(string='Overtime ID', required=True, copy=False, readonly=True,
                           index=True, default=lambda self: _('New'))

    name = fields.Char(string='Name')
    employee_id = fields.Many2one('hr.employee', string="Employee", default=_employee_get, readonly=True,
                                  required=True)
    department_id = fields.Many2one('hr.department',compute='get_department',store=True,
                                    string='Department', )
    request_date = fields.Date(string='Request Date', default=lambda self: fields.Date.today())
    # overtime_date = fields.Date(string='Overtime Date', required=False, default=fields.Datetime.now)
    overtime_date = fields.Date(string='Overtime From Date', required=False, default=fields.Date.context_today)
    overtime_date_end = fields.Date(string='Overtime End Date', required=False, default=fields.Date.context_today)
    employee_ids = fields.One2many('employee.overtime', 'overtime_id', string='Employees')
    # employee_ids = fields.Many2one('employee.overtime', 'overtime_id', string='Employees',
    # domain=[('department_id', '=', department_id)])
    paid = fields.Boolean(string='Paid')
    state = fields.Selection(string='Status', readonly=True, index=True, copy=False,
                             selection=STATE, required=False, default='draft')
    acvtivity_id = fields.Many2one('mail.activity', string="Activity")

    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id.id, readonly=True)

    payslip_id = fields.Many2one('hr.payslip')

    move_id = fields.Many2one('account.move', invisible='empty', readonly=True)

    days = fields.Integer(
        string='Days',
        help="The markup to be applied to the cost.",
        compute='_compute_days',
        store=False
    )

    total_amount = fields.Float('Total Amount')

    @api.depends('employee_ids')
    def _get_total_amount(self):
        """
        A method to compute total overtime amount per overtime record.
        """
        for rec in self:
            rec.total_amount = 0 
            total=0
            for emp in rec.employee_ids:
                total += emp.overtime_month_value
            
            rec.total_amount = total



    @api.depends('employee_id')
    def get_department(self):
        for rec in self:
            rec.department_id = rec.employee_id.department_id.id


    def get_attendance(self):
        for rec in self:
            for over in rec.employee_ids:
                employee = over.employee_id
                sum_hours = 0
                
                overtime_from_date = rec.overtime_date
                overtime_end_date = rec.overtime_date_end
                resualt = self.env['hr.attendance'].search([('employee_id', '=', employee.id),('check_in', '>=', overtime_from_date),('check_in', '<=', overtime_end_date)
                                                            ],
                                                           order='check_in DESC')
                
                for record in resualt:
                   
                    if record.check_in and record.check_out:
                        sumution = record.check_out.hour - record.check_in.hour
                        print('sssssssssssssssssssssss', sumution)
                        if sumution > employee.resource_calendar_id.hours_per_day:
                            sum_hours += sumution - employee.resource_calendar_id.hours_per_day
                            print('houres', sum_hours)
                            print("==============sum_hours==========================", sum_hours)

                    else:
                        print("================Eles=======================")
                over.actual_hour = sum_hours
                over.approved_hours = over.actual_hour

    # ***** Compute and search fields, and return value in model *****

    @api.depends('days')
    def _compute_days(self):
        for record in self:
            record.days = 0
            record.days = int(self.env['ir.config_parameter'].sudo().get_param('kambal_overtime.days'))


class EmployeeOvertime(models.Model):
    _name = 'employee.overtime'
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', string='Employee', required=True)
    overtime_id = fields.Many2one('overtime.request', string='Overtime')
    # overtime_date = fields.Date(string='Overtime Date', default= lambda self:self.context.get('overtime_date'))
    overtime_date = fields.Date(string='Overtime Date', default=lambda self: self.env.context.get('overtime_date'))
    estimated_hours = fields.Float(string='Estimated Overtime Hours', required=False)
    approved_hours = fields.Float(string='Approved Overtime Hours', required=False)

    tax_amount = fields.Float(string="Tax Amount", compute='compute_tax', store=True)
    overtime_month_value = fields.Float(string='Net Amount', compute='compute_net_amount', store=True)

    actual_hour = fields.Float(string="Actual Hours", required=False, compute='get_attendance', store=True)
    holiday = fields.Boolean(string='Holiday Overtime', compute='compute_holiday', store=True)
    # holiday = fields.Boolean(string='Holiday Overtime', store=True)
    overtime_hours = fields.Float(string='Overtime Hours', compute='compute_overtime_hours', store=True)
    overtime_amount = fields.Float(string='Overtime Amount', compute='compute_overtime_amount', store=True)
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.user.company_id)

    overtime_type = fields.Selection([
        ('working_day', 'Normal Overtime'),
        ('weekend', 'Holiday Overtime'),
        ], string='Overtime Type', required='1')

    @api.depends('overtime_amount')
    def compute_tax(self):
        for rec in self:
            rec.tax_amount = (rec.overtime_amount * 10) / 100

    @api.depends('overtime_amount')
    def compute_net_amount(self):
        for netAmount in self:
            netAmount.overtime_month_value = netAmount.overtime_amount

    @api.depends('actual_hour')
    def compute_approved_hours(self):
        for rec in self:
            rec.approved_hours = rec.actual_hour

    @api.depends('employee_id')
    def get_attendance(self):
        for rec in self:
            if rec.employee_id:
                sum_hours = 0
                
                overtime_from_date = rec.overtime_id.overtime_date
                overtime_end_date = rec.overtime_id.overtime_date_end
                resualt = self.env['hr.attendance'].search([('employee_id', '=', rec.employee_id.id),('check_in', '>=', overtime_from_date),('check_in', '<=', overtime_end_date)
                                                            ],
                                                           order='check_in DESC')
                
                for record in resualt:
                   
                    if record.check_in and record.check_out:
                        sumution = record.check_out.hour - record.check_in.hour
                        print('sssssssssssssssssssssss', sumution)
                        if sumution > rec.employee_id.resource_calendar_id.hours_per_day:
                            sum_hours += sumution - rec.employee_id.resource_calendar_id.hours_per_day
                            print('houres', sum_hours)
                            print("==============sum_hours==========================", sum_hours)

                    else:
                        print("================Eles=======================")
                rec.actual_hour = sum_hours
                rec.approved_hours = rec.actual_hour

    @api.depends('overtime_hours')
    def compute_overtime_amount(self):
        for rec in self:
            total = 0.0
            total_amount = 0.00
            overtime_hours_rate = 1
            # if rec.overtime_date.day <= 15:if
            if rec.overtime_type:
                total = rec.overtime_id.employee_id.contract_id.wage
                basic = (total * 45) / 100
                print ('xxxxxx',basic)
                cola = (total * 20) / 100
                print ('zzzzzzzz',cola)
                overtime_hours_rate = rec.overtime_id.employee_id.overtime_hours_rate
                print ('fffffffff',overtime_hours_rate)
                rec.overtime_amount = (basic + cola) / overtime_hours_rate/rec.overtime_hours
                # rec.overtime_amount = rec.actual_hour * (basic + cola)


    @api.depends('overtime_type', 'approved_hours')
    def compute_overtime_hours(self):
        for rec in self:
            if rec.overtime_type:
                if rec.overtime_type == 'working_day':
                    rec.overtime_hours = rec.approved_hours * rec.company_id.working_day_rate
                if rec.overtime_type == 'weekend':
                    rec.overtime_hours = rec.approved_hours * rec.company_id.weekend_rate
                # if rec.overtime_type == 'public_holiday':
                #     rec.overtime_hours = rec.approved_hours * rec.company_id.public_holiday_rate

    @api.onchange('overtime_id.overtime_date')
    def onchange_overtime_date(self):
        for rec in self:
            rec.overtime_date = rec.overtime_id.overtime_date


    @api.depends('employee_id', 'overtime_date')
    def compute_holiday(self):
        for rec in self:
            if rec.overtime_date:
                # check_in_date = datetime.strptime(rec.overtime_date, DEFAULT_SERVER_DATETIME_FORMAT).date()
                check_in_date = datetime.strptime(str(rec.overtime_date), '%Y-%m-%d').date()
                print('sssssssssssssssssssssss', check_in_date)

                # check_in_date = datetime.datetime.strptime(record.attendance_id.check_in,
                #         DEFAULT_SERVER_DATETIME_FORMAT).date()
                schedule_id = self.env['resource.calendar.attendance'].search(
                    [('calendar_id', '=', rec.employee_id.resource_calendar_id.id),
                     ('dayofweek', '=', str(check_in_date.weekday()))])
                # raise UserError(schedule_id.mapped('dayofweek'))
                if not schedule_id:
                    rec.holiday = True
                if schedule_id:
                    rec.holiday = False


class overtime_line(models.Model):
    _name = 'overtime.line'

    employee_id = fields.Many2one('hr.employee', string='Employee')
    # employee_hour_salary = fields.Float(string="Hour Value", compute='compute_hour_value')
    employee_hour_salary = fields.Float(string="Hour Value")
    # employee_salary = fields.Float(string="Basic Salary", compute='compute_hour_value')
    employee_salary = fields.Float(string="Basic Salary", compute='get_salary')
    # employee_day_salary = fields.Float(string="Day Value", compute='compute_hour_value')
    # overtime_month = fields.Float(string='Hours Total')
    overtime_month = fields.Float(string='Hours Total', compute='get_sum')
    overtime_month_value = fields.Float(string='Net Amount')
    tax_amount = fields.Float(string="Tax Amount")
    overtime_amount = fields.Float(string="Overtime Amount")
    total_work_hour = fields.Float(string='Total Normal Hour')
    total_work_overtime = fields.Float(string='Normal Hour * 1.5', compute='get_total_normal_hour')
    total_holiday_hour = fields.Float(string='Total Holiday Hour')
    total_holiday_overtime = fields.Float(string='Holiday Hour * 2')
    days_no = fields.Integer(string='Days')
    overtime_line_id = fields.Many2one('hr.overtime.month', string='Workers Overtime Month', ondelete='cascade')
    employee_line_id = fields.Many2one('hr.overtime.month', string='Employees Overtime Month', ondelete='cascade')
    emp_type = fields.Selection([('worker', 'Worker'), ('employee', 'Employee'), ('higher', 'Higher Degrees')],
                                string='Employee Type',
                                store=True)

    meal = fields.Float(string='Meal Amount')
    transport = fields.Float(string='Transport Amount')

    @api.depends('total_work_hour', 'total_holiday_hour')
    def get_sum(self):
        for rec in self:
            rec.update({'overtime_month': rec.total_work_hour + rec.total_holiday_hour})

    @api.depends('total_work_hour')
    def get_total_normal_hour(self):
        for rec in self:
            rec.update({'total_work_overtime': rec.total_work_hour * 1.5})

    @api.depends('employee_id')
    def get_salary(self):
        for rec in self:
            rec.employee_salary =0.0
            if rec.employee_id:
                rec.employee_salary = rec.employee_id.contract_id.wage

    # @api.depends('name')
    # @api.depends('employee_id')
    # def compute_hour_value(self):
    #     for rec in self:
    #         overtime_settings = self.env['overtime.setting'].sudo().search([], limit=1, order='date DESC')
    #         if rec.name:
    #             salary = rec.name.contract_id.wage
    #             rec.employee_salary = salary
    #             if rec.emp_type == 'worker':
    #                 rec.employee_hour_salary = salary / overtime_settings.days_worker
    #             if rec.emp_type == 'employee':
    #                 rec.employee_hour_salary = salary / overtime_settings.days_employee
    # if rec.emp_type == 'higher':
    #     rec.employee_day_salary = salary / 30


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    days = fields.Integer(string='Days', )
    # basic_percent = fields.Float(string='Basic Percentage')
    basic_first = fields.Float(string='Basic First')
    basic_last = fields.Float(string='Basic Last')
    cola_percent = fields.Float(string='COLA Percentage')
    overtime_tax = fields.Many2one('account.tax', string='Tax', )

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            days=float(self.env['ir.config_parameter'].sudo().get_param('kambal_overtime.days')),
            basic_first=float(self.env['ir.config_parameter'].sudo().get_param('kambal_overtime.basic_first')),
            basic_last=float(self.env['ir.config_parameter'].sudo().get_param('kambal_overtime.basic_last')),
            cola_percent=float(self.env['ir.config_parameter'].sudo().get_param('kambal_overtime.cola_percent')),
            overtime_tax=int(self.env['ir.config_parameter'].sudo().get_param('kambal_overtime.overtime_tax'))

        )
        return res


    def set_values(self):
        super(ResConfigSettings, self).set_values()
        # self.env['ir.config_parameter'].sudo().set_param('ii_sayed_overtime.days', Decimal(self.days))
        self.env['ir.config_parameter'].sudo().set_param('kambal_overtime.days', self.days)
        self.env['ir.config_parameter'].sudo().set_param('kambal_overtime.basic_first', self.basic_first)
        self.env['ir.config_parameter'].sudo().set_param('kambal_overtime.basic_last', self.basic_last)
        self.env['ir.config_parameter'].sudo().set_param('kambal_overtime.cola_percent', self.cola_percent)
        self.env['ir.config_parameter'].sudo().set_param('kambal_overtime.overtime_tax', self.overtime_tax.id)


class HrSalaryRule(models.Model):
    # """"""
    _inherit = 'hr.salary.rule'

    use_type = fields.Selection(string='Use Type', selection=[('general', 'General'), ('special', 'Special'),('over_time','Over Time')], default='general')
