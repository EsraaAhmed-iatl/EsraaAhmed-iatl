# -*- coding: utf-8 -*-
# overtime
from . import kambal_overtime
from . import kambal_overtime_request
from . import res_config_settings
from . import payslip


# Collection

from . import collecting_overtime_request



