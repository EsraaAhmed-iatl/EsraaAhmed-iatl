from collections import defaultdict

from odoo import models, fields, api, _

STATE = [
    ('draft', 'Draft'),
    ('supervisor_direct_manager', 'supervisor/direct manager'),
    ('hr_department', 'HR Department'),
    ('direct_manager', 'supervisor/direct manager'),
    ('hr', 'HR'),
    ('done', 'Done'),
]


class OvertimeRequestCollecting(models.Model):
    _name = 'overtime.request.collecting'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Overtime Request Collecting"
    _rec_name = 'department_id'

    def button_draft(self):
        for rec in self:
            order_detail = self.env['overtime.request'].search([('overtime_date', '>=', rec.date_from),
                                                                ('overtime_date', '<=', rec.date_to)])
            for line in order_detail:
                line.state = 'supervisor_direct_manager'
            self.state = 'supervisor_direct_manager'
    def button_direct_approve(self):
        for rec in self:
            order_detail = self.env['overtime.request'].search([('overtime_date', '>=', rec.date_from),
                                                                ('overtime_date', '<=', rec.date_to)])
            for line in order_detail:
                line.state = 'hr_department'
        self.state = 'hr_department'


    def button_hr_department(self):
        # vals = {
        #     'activity_type_id': self.env['mail.activity.type'].sudo().search(
        #         [('name', 'like', u'Call')],
        #         limit=1).id,
        #     'res_id': self.id,
        #     'res_model_id': self.env['ir.model'].sudo().search(
        #         [('model', 'like', 'overtime.request')], limit=1).id,
        #     'user_id': self.create_uid.id,
        #     'summary': u'New Overtime Request Approve ',
        # }
        # # add lines
        # acvtivity_id = self.env['mail.activity'].sudo().create(vals)
        for rec in self:
            order_detail = self.env['overtime.request'].search([('overtime_date', '>=', rec.date_from),
                                                                ('overtime_date', '<=', rec.date_to)])
            for line in order_detail:
                line.state = 'direct_manager'
        self.state = 'direct_manager'

    def button_direct_hr(self):
        for rec in self:
            order_detail = self.env['overtime.request'].search([('overtime_date', '>=', rec.date_from),
                                                                ('overtime_date', '<=', rec.date_to)])
            for line in order_detail:
                line.state = 'hr'
        self.state = 'hr'


    def button_hr(self):
        for rec in self:
            order_detail = self.env['overtime.request'].search([('overtime_date', '>=', rec.date_from),
                                                                ('overtime_date', '<=', rec.date_to)])
            for line in order_detail:
                line.state = 'done'

        self.state = 'done'



    def get_total_request(self):
        product_summary_dict = defaultdict(dict)
        self.overtime_request_collecting_line_ids.unlink()
        overtime_list = []

        if self.date_from and self.date_to:
            order_detail = self.env['overtime.request'].search([('overtime_date', '>=', self.date_from),
                                                                ('overtime_date', '<=', self.date_to)])
            if order_detail:
                for each_order in order_detail:
                    for each_order_line in each_order.employee_ids:
                        if each_order_line.employee_id.id in product_summary_dict:
                            estimated_hours = product_summary_dict[each_order_line.employee_id.id]['a']
                            actual_hour = product_summary_dict[each_order_line.employee_id.id]['b']
                            estimated_hours += each_order_line.estimated_hours
                            actual_hour += each_order_line.actual_hour
                            product_summary_dict[each_order_line.employee_id.id]['a'] = estimated_hours
                            product_summary_dict[each_order_line.employee_id.id]['b'] = actual_hour
                        else:
                            estimated_hours = each_order_line.estimated_hours
                            actual_hour = each_order_line.actual_hour
                            product_summary_dict[each_order_line.employee_id.id]['a'] = estimated_hours
                            product_summary_dict[each_order_line.employee_id.id]['b'] = actual_hour
                for key in product_summary_dict.keys():
                    overtime_list.append([0, 0, {
                        'employee_id': key,
                        'estimated_hour': product_summary_dict[key]['a'],
                        'actual_hour': product_summary_dict[key]['b'],
                    }])
                self.write({'overtime_request_collecting_line_ids': overtime_list})
        # for rec in self:
        #     self.overtime_request_collecting_line_ids.unlink()
        #     overtime_list = []
        #     if rec.department_id:
        #         res = self.env['employee.overtime'].search([
        #             ('overtime_id.department_id', '=', rec.department_id.id),
        #             ('overtime_date', '>=', rec.date_from),
        #             ('overtime_date', '<', rec.date_to),
        #         ])
        #         for line in res:
        #             # if line.employee_id.id in overtime_list:
        #
        #             overtime_list.append([0, 0, {
        #                 'employee_id': line.employee_id.id,
        #                 'estimated_hour': line.estimated_hours,
        #                 'overtime_request_collecting_id': rec.id
        #
        #             }])
        #             # for list_item in overtime_list:
        #             #     print('=-======',list_item)
        #         self.write({'overtime_request_collecting_line_ids': overtime_list})
        #

    department_id = fields.Many2one(comodel_name="hr.department",
                                    string="Department", required=False, )
    date_from = fields.Date(string="Date From", required=False)
    date_to = fields.Date(string="Date To", required=False)
    state = fields.Selection(string='Status', readonly=True, index=True, copy=False,
                             selection=STATE, required=False, default='draft')
    overtime_request_collecting_line_ids = fields.One2many(comodel_name="overtime.request.collecting.line",
                                                           inverse_name="overtime_request_collecting_id",
                                                           string="", required=False, )


class OvertimeRequestCollectingLine(models.Model):
    _name = 'overtime.request.collecting.line'

    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=False, )
    estimated_hour = fields.Float(string="Estimated Overtime Hours", required=False, )
    actual_hour = fields.Float(string="Actual Overtime Hours", required=False, )

    #
    overtime_request_collecting_id = fields.Many2one(comodel_name="overtime.request.collecting",
                                                     string="", required=False, )

    def action_open_overtime_request(self):
        return {
            'name': _('Overtime Request'),
            'view_type': 'form',
            'res_model': 'employee.overtime',
            'view_id': False,
            'view_mode': 'tree,form',
            'domain': [('employee_id', '=', self.employee_id.id),
                       ('overtime_id', '!=', False)],
            'type': 'ir.actions.act_window',
        }
