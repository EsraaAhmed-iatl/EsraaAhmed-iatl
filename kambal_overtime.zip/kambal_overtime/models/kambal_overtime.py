from datetime import datetime
from dateutil import relativedelta
import time
from odoo import api, fields, models, tools, _
from odoo.exceptions import UserError, ValidationError
import babel


class HrOvertimeMonth(models.Model):
    _name = 'hr.overtime.month'
    _description = 'Month Overtime'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    def button_send_to_finance(self):
        for rec in self:
            rec.write({'state': 'finance'})
            # rec.notification('account.group_account_user')

    def button_approve_finance(self):
        for rec in self.overtime_line_ids:
            overtime_ids = self.env['employee.overtime'].search(
                [('employee_id', '=', rec.employee_id.id),
                 ('overtime_date', '>=', self.date_from),
                 ('overtime_date', '<=', self.date_to),
                 ('paid', '=', False),
                 ('overtime_id.state', '=', 'done')])
            for request in overtime_ids:
                request.paid = True
            rec.write({'state': 'done'})
            # rec.notification('hr.group_hr_manager')

    def notification(self, group):
        self.activity_id.unlink()
        for rec in self:
            group_department = self.env.ref(group).id
            print("=========================", group_department)
            self.env.cr.execute(
                '''SELECT uid FROM res_groups_users_rel WHERE gid = %s order by uid''' % (
                    group_department))

            #         # schedule activity for user(s) to approve
            for fm in list(filter(lambda x: (
                    self.env['res.users'].sudo().search([('id', '=', x), ('company_id', '=', self.company_id.id)])),
                                  self.env.cr.fetchall())):
                vals = {
                    'activity_type_id': self.env['mail.activity.type'].sudo().search(
                        [('name', 'like', u'Call')],
                        limit=1).id,
                    # 'res_id': self.check_ids[0]  ,
                    'res_id': self.id,
                    'res_model_id': self.env['ir.model'].sudo().search(
                        [('model', 'like', 'hr.overtime.month')], limit=1).id,
                    'user_id': fm[0] or 1,
                    'summary': u'New Overtime Month Approve ',
                }

                #             # add lines
                acvtivity_id = self.env['mail.activity'].sudo().create(vals)

    @api.model
    def create(self, vals):
        if vals.get('name_seq', _('New')) == _('New'):
            vals['name_seq'] = self.env['ir.sequence'].next_by_code('overtime.month.sequence') or _('New')
        result = super(HrOvertimeMonth, self).create(vals)
        return result

    name_seq = fields.Char(string='Sequence', required=True, copy=False, readonly=True,
                           index=True, default=lambda self: _('New'))

    name = fields.Char(string='Overtime')
    department_id = fields.Many2one('hr.department', string='Department')
    date_from = fields.Date(string='Date From', required=True,
                            default=time.strftime('%Y-%m-01'))
    date_to = fields.Date(string='Date To', required=True,
                          default=str(datetime.now() + relativedelta.relativedelta(months=+1, day=1, days=-1))[:10],
                          )
    # overtime = fields.Float("Monthly Overtime", readonly=True, compute='compute_month_overtime_hours', store=True)
    overtime_line_ids = fields.One2many('overtime.line', 'overtime_line_id', string='Workers Overtime Month')
    total_amount = fields.Float(string='Total Overtime', compute='compute_total_overtime')

    # total_amount = fields.Float(string='Total Overtime', compute='compute_total_overtime')
    user_a = fields.Many2one('res.users', string='User Approve A')
    user_b = fields.Many2one('res.users', string='User Approve B')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('finance', 'Waiting Finance Approval'),
        ('done', 'Done'),
    ], string="State", default='draft', tracking=True, copy=False)
    activity_id = fields.Many2one('mail.activity', string='Activity')
    employee_id = fields.Many2one('hr.employee')
    company_id = fields.Many2one('res.company', default=lambda self: self.env.user.company_id.id, readonly=True)

    # @api.depends('overtime_line_ids', 'employees_line_ids')
    @api.depends('overtime_line_ids')
    def compute_total_overtime(self):
        for rec in self:
            amount = 0.0
            rec.total_amount = 0.0
            if rec.overtime_line_ids:
                for over1 in rec.overtime_line_ids:
                    amount += over1.total_work_hour
                rec.total_amount = amount

    @api.depends('date_from', 'date_to')
    def compute_overtime_month(self):

        for x in self:
            ttyme = datetime.fromtimestamp(time.mktime(time.strptime(str(x.date_from), "%Y-%m-%d")))
            locale = self.env.context.get('lang', 'en_US')
            x.name = _('Overtime for %s') % (
                tools.ustr(babel.dates.format_date(date=ttyme, format='MMMM-y', locale=locale)))
            # overtime_obj = x.env['hr.overtime']
            exist_employee_list = []
            tax_id = int(self.env['ir.config_parameter'].sudo().get_param('ii_sayed_overtime.overtime_tax'))
            tax_id = self.env['account.tax'].browse(tax_id).amount
            overtime_obj = x.env['employee.overtime']
            overtime_line_obj = x.env['overtime.line']
            employee_obj = self.env['hr.employee'].search([('department_id', '=', x.department_id.id)])
            print('eeeeeeeeeeeeeeeeeeeeeeeeeeee', employee_obj)

            self.overtime_line_ids.unlink()
            print(len(employee_obj))
            for employee in employee_obj:
                total_overtime = 0.0
                sum_hours = 0.0
                sum_work_hours = 0.0
                sum_holiday_hours = 0.0
                total_amount = 0.0
                overtime_holiday = 0.0
                overtime_working = 0.0
                total_work_overtime = 0.0
                total_holiday_overtime = 0.0
                total_hours = 0.0
                tax_amount = 0.0
                overtime_amount = 0.0
                overtime_month_value = 0.0
                days_high = 0.0
                meals = 0.0
                transports = 0.0

                overtime_ids = overtime_obj.search(
                    [('employee_id', '=', employee.id),
                     ('overtime_date', '>=', x.date_from),
                     ('overtime_date', '<=', x.date_to),
                     ('overtime_id.state', '=', 'done')])
                print('ttttttttttttttttttttt', overtime_ids)
                if overtime_ids:
                    holiday_overtime = overtime_ids.filtered(lambda o: o.holiday == True)
                    working_overtime = overtime_ids.filtered(lambda o: o.holiday == False)
                    print("==============================", overtime_ids.ids)

                    total_overtime = sum(overtime_ids.mapped('overtime_amount'))
                    tax_amount = sum(overtime_ids.mapped('overtime_amount'))
                    # tax_amount = sum(overtime_ids.mapped('overtime_amount')) * tax_id / 100
                    net = total_overtime - tax_amount
                    exist_employee_list.append([0, 0, {
                        'employee_id': employee.id,
                        # 'name': employee_id,
                        # 'total_work_hour': employee.approved_hours,
                        'total_work_hour': sum(working_overtime.mapped('approved_hours')),
                        'total_holiday_hour': sum(holiday_overtime.mapped('approved_hours')),
                        'total_holiday_overtime': sum(holiday_overtime.mapped('overtime_hours')),
                        'total_work_overtime': sum(working_overtime.mapped('overtime_hours')),
                        # 'overtime_month': overtime_line_obj.total_work_hour+overtime_line_obj.total_holiday_hour,
                        'overtime_amount': total_overtime,
                        'tax_amount': tax_amount,
                        'overtime_month_value': sum(working_overtime.mapped('overtime_month_value')),
                        'overtime_line_id': x.id,
                        'employee_line_id': False,
                    }])
                    print("=============================", exist_employee_list)
            # overtime_line_obj.create(exist_employee_list)
        self.write({'overtime_line_ids': exist_employee_list})
