# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime
from odoo.exceptions import UserError, Warning
import babel
import time
from dateutil.relativedelta import relativedelta
from odoo import tools
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import pandas as pd


class OvertimeWizard(models.TransientModel):
    _name = 'overtime.wizard'

    date_from = fields.Date(string="Date From", required=True)
    date_to = fields.Date(string="Date To", required=True)
    department_id = fields.Many2one(comodel_name="hr.department", string="Department", required=True)
    estimated_hour = fields.Float(string="Estimated Overtime Hours", required=True)

    def create_overtime(self):
        for rec in self:
            for date_cr in pd.date_range(rec.date_from, rec.date_to):
                res_department = self.env['hr.employee'].search([('department_id', '=', rec.department_id.id)])
                for overtime in self:
                    overtime_id = self.env['overtime.request'].create({
                        'department_id': rec.department_id.id,
                        'request_date': date_cr,
                        'overtime_date': date_cr,
                    })
                    for emp in res_department:
                        employee_overtime_line = self.env['employee.overtime'].create({
                            'overtime_id': overtime_id.id,
                            'employee_id': emp.id,
                            'estimated_hours': rec.estimated_hour,
                            'approved_hours': rec.estimated_hour,
                            'overtime_date': date_cr,

                        })
                        for record in employee_overtime_line :
                            check_in_date = datetime.strptime(str(record.overtime_date), '%Y-%m-%d').date()
                            print('sssssssssssssssssssssss', check_in_date)

                            # check_in_date = datetime.datetime.strptime(record.attendance_id.check_in,
                            #         DEFAULT_SERVER_DATETIME_FORMAT).date()
                            schedule_id = self.env['resource.calendar.attendance'].search(
                                [('calendar_id', '=', record.employee_id.resource_calendar_id.id),
                                 ('dayofweek', '=', str(check_in_date.weekday()))])
                            # raise UserError(schedule_id.mapped('dayofweek'))
                            if not schedule_id:
                                record.holiday = True
                            if schedule_id:
                                record.holiday = False

                            if record.holiday:
                                record.overtime_hours = record.approved_hours * 2
                            if not record.holiday:
                                record.overtime_hours = record.approved_hours * 1.5

            # if rec.overtime_date:
            #     # check_in_date = datetime.strptime(rec.overtime_date, DEFAULT_SERVER_DATETIME_FORMAT).date()
            #     check_in_date = datetime.strptime(str(rec.overtime_date), '%Y-%m-%d').date()
            #     print('sssssssssssssssssssssss', check_in_date)
            #
            #     # check_in_date = datetime.datetime.strptime(record.attendance_id.check_in,
            #     #         DEFAULT_SERVER_DATETIME_FORMAT).date()
            #     schedule_id = self.env['resource.calendar.attendance'].search(
            #         [('calendar_id', '=', rec.employee_id.resource_calendar_id.id),
            #          ('dayofweek', '=', str(check_in_date.weekday()))])
            #     # raise UserError(schedule_id.mapped('dayofweek'))
            #     if not schedule_id:
            #         rec.holiday = True
            #     if schedule_id:
            #         rec.holiday = False

    # # @api.depends('employee_id', 'overtime_date')
    # @api.depends('employee_id', 'overtime_date')
    # def compute_holiday(self):
    #     for rec in self:
    #         if rec.overtime_date:
    #             # check_in_date = datetime.strptime(rec.overtime_date, DEFAULT_SERVER_DATETIME_FORMAT).date()
    #             check_in_date = datetime.strptime(str(rec.overtime_date), '%Y-%m-%d').date()
    #             print('sssssssssssssssssssssss', check_in_date)
    #
    #             # check_in_date = datetime.datetime.strptime(record.attendance_id.check_in,
    #             #         DEFAULT_SERVER_DATETIME_FORMAT).date()
    #             schedule_id = self.env['resource.calendar.attendance'].search(
    #                 [('calendar_id', '=', rec.employee_id.resource_calendar_id.id),
    #                  ('dayofweek', '=', str(check_in_date.weekday()))])
    #             # raise UserError(schedule_id.mapped('dayofweek'))
    #             if not schedule_id:
    #                 rec.holiday = True
    #             if schedule_id:
    #                 rec.holiday = False
