# -*- coding: utf-8 -*-
{
    'name': "Kambal HR",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    'category': 'HR',
    'version': '0.1',

    # any module necessary for this one to work correctly
    # 'depends': ['base', 'hr', 'hr_holidays', 'hr_contract', 'employee_profile',
    'depends': ['base','base_setup', 'hr', 'hr_holidays', 'hr_contract', 'hr_payroll',
                'hr_recruitment', 'hr_attendance'],

    # always loaded
    'data': [

        'data/alsayed_sequance.xml',
        'security/ir.model.access.csv',
      

        # collection
        'views/kambal_overtime_view.xml',
        'views/kambal_overtime_request_views.xml',
        'views/collecting_overtime_request_view.xml',
	'wizard/overtime_wz_view.xml',
	'views/res_config_settings_views.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
